/*
	eidhne kennedy
	21347021
	2021/10/12
	assignment 3
*/

#include <stdio.h>

void main() 
{

	int day1 = 0.0;   // initialising "day" variables
	int day2 = 0.0;	
	int day3 = 0.0;
	int day4 = 0.0;

	int average;	  // declaring averaging variable
	int c_spend;	  // declaring average spend per customer variable 

	printf("enter the total sales for day 1 in euro:\n");		// getting values for each day
	scanf_s("%d", &day1);										// would probably be easier with an array and a for loop?

	printf("enter the total sales for day 2 in euro:\n");
	scanf_s("%d", &day2);

	printf("enter the total sales for day 3 in euro:\n");
	scanf_s("%d", &day3);

	printf("enter the total sales for day 4 in euro:\n");
	scanf_s("%d", &day4);

	average = (day1 + day2 + day3 + day4) / 4;						// find the average and print it
	printf("the average over the 4 days entered is: %d\n", average);


	if (average < 10000) {				// if statement to see if sales were low, normal, or high
		printf("sales were low during this time period\n");
	}
	else if (average < 15000) {
		printf("sales were normal during this period\n");
	}
	else {
		printf("sales were high during this period\n");
	}

	c_spend = average / 500;				// find average spend per customer and print it out
	printf("the average spend per customer was %d euro\n\n\n\n\n", c_spend);

	main();				// finally, call main again for repetition purposes

}