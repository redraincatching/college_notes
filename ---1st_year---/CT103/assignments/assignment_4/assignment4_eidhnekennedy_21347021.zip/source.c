/*
	�idhne kennedy
	21347021
	2021/10/19
*/

#include <stdio.h>
void main() {

	int oldest = 0;     // oldest child
	int youngest = 20;   // youngest child
	float avg;        // average age
	int total_kids = 0;      // total children
	int total_age = 0;		 // total age
	int current_age;     // the age entered
	int counter = 0;	// counts number of kids
	
	do {
		printf("enter the age of child %d:", counter+1);
		scanf_s("%d", &current_age);
		printf("\n");
		if (0 <= current_age && current_age < 18) {
			if (current_age > oldest) {
				oldest = current_age;
			}
			if (current_age < youngest) {
				youngest = current_age;
			}
			total_kids++;
			counter++;
			total_age += current_age;
			
		}
		else if (current_age >= 18) {
			printf("not a child.\n");
		}


	} while (current_age >= 0);

	avg = total_age / total_kids;
	printf("there are %d children.\n", total_kids);
	printf("the oldest child is %d\n", oldest);
	printf("the youngest child is %d\n", youngest);
	printf("the average age is %0.1f\n\n", avg);

}