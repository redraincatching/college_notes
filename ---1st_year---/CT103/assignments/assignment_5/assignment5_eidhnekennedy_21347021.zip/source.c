/*
eidhne kennedy
21347021
2021/10/26
assignment 5
*/


#include <stdio.h>
void main() {

	float daily_sales[32];	// initialise the array at a month plus one, that should be reasonable
	float daily_average;
	float total_sales = 0.0;		// should both be self-explanatory
	int additional_days;		// ask whether or not to add additional days

	for (int i = 0; i < 7; i++) {
		printf("enter the total daily sales (in euro) for day %d: ", i + 1);
		scanf_s("%f", &daily_sales[i]);
		total_sales += daily_sales[i];		// cycles through entry of the first week, adds to array, adds to total
	}

	daily_average = total_sales / 7;

	printf("total sales over this 7-day period was %0.2f \n", total_sales);		// print out final values
	printf("the average daily sales over the same period was %0.2f\n", daily_average);
	
	printf("how many additional days would you like to enter? ");
	scanf_s("%d", &additional_days);
	
	if (additional_days > 0) {
		int i = 0;
		while (i < additional_days) {		// same thing again, but for additional days
			printf("enter the total daily sales (in euro) for day %d: ", i + 8);
			scanf_s("%f", &daily_sales[i + 7]);
			total_sales += daily_sales[i + 7];
			i++;
		}

		daily_average = total_sales / (7 + additional_days);

		printf("total sales over this %d-day period was %0.2f \n", additional_days + 7, total_sales);		// print out final values
		printf("the average daily sales over the same period was %0.2f\n", daily_average);
	}

	int len_array = 7 + additional_days;	// this is annoying, but makes the for loop work

	for (int i = 0; i < len_array; i++) {			// print everything out
		printf("sales for day %d: %0.2f euro\n", i + 1, daily_sales[i]);
	}
	
}